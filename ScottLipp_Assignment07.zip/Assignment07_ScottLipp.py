'''
Title:  Assignment 07 - Working with Exceptions and Pickling
Developer:  Scott Lipp
Created on:  5/13/2018
Class:  IT FDN 100 A: Intro to Programming (Python)
Change Log:  N/A
Purpose:    This program allows a user to import and edit a To-Do list from a binary file.
            It emphasizes the use of exceptions to trap errors and using pickled data
            (i.e. reading and writing to a binary file)
'''

#--------------------  Data  --------------------#

#File location for loading/saving data. If the directory doesn't already exist, some capability to create it
objFileLoc = "C:\_PythonClass\Todo.dat"

#Menu displayed to user
strMenu = "\n\
\t1: Display 'ToDo' list\n\
\t2: Add an item to 'ToDo' list\n\
\t3: Remove an item from 'ToDo' list\n\
\t4: Save the current list\n\
\t5: Exit the program\n"

#Header displayed above task/priority list
strHeader = "ITEM, PRIORITY\n---------------"



#--------------------  Processing --------------------#

class Processing(object):
    """For adding and deleting entries in the To-Do list"""

    @staticmethod
    def rowAdd(listName, dictName):
        """Adds a new task and its priority to the To-Do list"""

        boolAdd = False
        for row in listName:
            if row["Task"] == dictName["Task"]:
                boolAdd = True
        if boolAdd == False:
            listName.append(dictName)
        return [listName, boolAdd]

    @staticmethod
    def rowDelete(listName, strItem):
        """Deletes an existing task and its priority from the To-Do list"""

        boolDelete = False
        for row in listName:
            if row["Task"] == strItem:
                listName.remove(row)
                boolDelete = True
        return [listName, boolDelete]


#-------------------- Input/Output --------------------#

class Input_Output(object):
    """For loading/saving data and displaying information to user"""

    @staticmethod
    def dataLoad(fileName):
        """If a file already exists, loads data into memory. If not, attempts to create the file"""

        import pickle  # Use 'pickle' class to read binary files
        listRetrieve = []  # Create empty list for storing data
        try:
            objBinFile = open(fileName, "rb")  # Create object to hold data from the binary file
            listRetrieve = pickle.load(objBinFile)  # Expecting data in a list form, store as list
            objBinFile.close()
            return listRetrieve
        except IOError:  # Catch errors associated with a missing/inaccurate file name
            print("\nThis program is expecting an existing file at '" + objFileLoc + "' but could not be found.")
            strErrorInput = input("\nWould you like to create a new file (" + objFileLoc + ")? (y/n): ")
            if strErrorInput.strip().lower()[0] == "y":
                import pickle
                try:  # A crude attempt to verify the directory exists.  Attempts to create file if directory is valid
                    objBinFile = open(fileName, "wb")
                    objBinFile.close()
                except:
                    try:  # If the directory doesn't exist, attempts to create the directory
                        # Warning: this only works for a particular file pattern (C:\(root folder)\(filename)
                        import os
                        listDirectory = []
                        strDirectory = objFileLoc.split("\\")  # Split directory into drive and folder name
                        for item in strDirectory:
                            listDirectory.append(item)  # Create list to hold directory info for easy indexing
                        if len(listDirectory) == 3:  # Expecting: 'Drive', 'Folder', 'File Name'. If 3 elements, proceed
                            os.chdir(listDirectory[0] + "\\")  # Change directory to 'Drive' name
                            os.mkdir(listDirectory[1])  # Create new directory (folder)
                        else:
                            print(
                                "\nFile path was not created correctly and will not properly save. Please exit without saving.")
                    except Exception as e:  # Catch possible errors when trying to create new directory
                        print("\nUnable to create correct file path.  Python error code :" + str(e))
                        input("\nPress enter to close: ")
                return listRetrieve  # A valid list -- even if empty -- is required to proceed with program
            else:
                input("\nPress enter to close the program: ")
        except Exception as e:  # A catch-all for non-IO errors.  The program will not be able to run successfully
            print("\nAn error occurred during the data load process.")
            print("\nBuilt-in Python error code: " + str(e))
            input("\nPress enter to close program: ")

    @staticmethod
    def displayData(listName):
        """Displays the contents of the To-Do list"""

        print("\n" + strHeader)
        for row in listName:  # Iterates over each item in the list
            print(
                row["Task"] + ", " + row["Priority"])  # Expecting data in dictionary form with keys "Task" & "Priority"

    @staticmethod
    def dataSave(listName, fileName):
        """Saves the To-Do list as a binary file"""

        import pickle  # Use 'pickle' class to conveniently save as a binary file
        boolSave = False  # Create Boolean flag to indicate if save was successful
        strError = ""
        try:
            objBinFile = open(fileName, "wb")  # Overwrites an existing file by the same name
            pickle.dump(listName, objBinFile)  # Data saved as dictionary items nested in a single list
            objBinFile.close()
            boolSave = True
        except Exception as e:  # Catch any errors (e.g. file changed between starting program and saving data)
            strError = str(e)   # Store the error as a string to be passed back to the I/O section
        finally:
            return [boolSave, strError]

    @staticmethod
    def menuLoop(listName):
        """Loops through the menu of options to allow the user to view, modify, and save the To-Do list"""

        while True:
            print(strMenu)
            strSelect = input("Enter your selection (1-5): ")
            if strSelect.strip() == "1":    # Option 1: Display data. Call function
                Input_Output.displayData(listName)
            elif strSelect.strip() == "2":  # Option 2: Add data.
                while True:     # Loop through until a non-empty-string is declared as the task
                    strTask = input("Enter the name of the task you'd like to add: ")
                    if strTask == "":
                        print("Task name cannot be empty.")
                    else:
                        break
                while True:     # Loop through until a non-empty-string is declared as the priority
                    strPriority = input("Enter the priority level for '" + strTask.title() + "': ")
                    if strPriority == "":
                        print("Priority level cannot be empty.")
                    else:
                        break
                dictItem = {"Task": strTask.title(), "Priority": strPriority.lower()}   # Create dictionary for Task/Priority
                listName, boolFlag = Processing.rowAdd(listName, dictItem)  #Pass data to 'rowAdd' function and receive return values
                if boolFlag == True:    # Indicates an exact match for the task was found
                    print("\n'" + strTask.title() + "' cannot be added because it's already on the list.")
                else:
                    print("\n'" + strTask.title() + "' was successfully added.")
            elif strSelect.strip() == "3":      #Option 3: Delete an item from the To-Do list
                strTask = input("Enter the task you'd like to remove: ")
                listName, boolFlag = Processing.rowDelete(listName, strTask.title())    # Data passed to function and return values
                if boolFlag == True:    # Indicates an exact match for the task was found
                    print("\n'" + strTask.title() + "' was successfully deleted from the list.")
                else:
                    print("\n'" + strTask.title() + "' was not found in the list.")
            elif strSelect.strip() == "4":      # Option 4: Save data
                boolFlag, strError = Input_Output.dataSave(listName, objFileLoc)    # Data passed to function and return variables
                if boolFlag == True:    # Indicates successful save
                    print("\nFile was saved (" + objFileLoc + ").")
                else:
                    print("\nThe following error occurred and the data was not saved: " + strError)
            elif strSelect.strip() == "5":  # Option 5: Exit.  Ask to save data to file first
                strSave = input("Would you like to save the list to file before quitting? (y/n): ")
                if strSave.strip().lower()[0] == "y":
                    boolFlag, strError = Input_Output.dataSave(listName, objFileLoc)    # Data passed to function and returned variables
                    if boolFlag == True:    # Indicates successful save
                        print("\nFile was saved here:  " + objFileLoc)
                    else:
                        print("\nThe following error occurred and the data was not saved: " + strError)
                break
            else:   # Catches any entry that's not '1-5' and allows the loop to proceed
                print("\nInvalid selection. Please try again.")

        input("\nPress enter to close program: ")   # Pause program for user before closing


#-------------------- Program Start --------------------#

listToDo = Input_Output.dataLoad(objFileLoc)    # Step 1:  Call 'dataLoad' function and return as a list
Input_Output.displayData(listToDo)              # Step 2:  Call 'displayData' function to display list contents to user
Input_Output.menuLoop(listToDo)                 # Step 3:  Initiate loop through Menu options to edit/save the list

