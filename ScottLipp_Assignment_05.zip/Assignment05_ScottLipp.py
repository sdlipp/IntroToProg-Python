'''
Title:  Assignment 05 - Working with Lists & Dictionaries
Developer:  Scott Lipp
Created on:  4/27/2018
Class:  IT FDN 100 A: Intro to Programming (Python)
Change Log:  N/A
Purpose:    This program allows a user to import and edit a To-Do list from a text file.
            It introduces the concept of working with Lists and Dictionaries, as well
            as reading and storing data from a text file.
'''

#--------------------  Data  --------------------#

objFileLoc = "C:\_PythonClass\Todo.txt"
objTxtFile = ""
dictItem = {}
strDictKey = ""
strDictVal = ""
listToDo = []
intFlag = 0
strUserOption = ""
strItemInput = ""
strPriorityInput = ""
strOptions = "\n\
\t1: Display 'ToDo' list\n\
\t2: Add an item to 'ToDo' list\n\
\t3: Remove an item from 'ToDo' list\n\
\t4: Save the current list\n\
\t5: Exit the program\n"
strDictHeader = "ITEM, PRIORITY\n---------------"

#--------------------  Processing & Input/Output  --------------------#

#Reads text from an existing .txt file and imports each item & its
#priority into a dictionary.  A list is compiled of all items & priorities
objTxtFile = open(objFileLoc, "r")
for row in objTxtFile:
    strDictKey = row.strip().split(",")[0]
    strDictVal = row.strip().split(",")[1]
    dictItem = {strDictKey: strDictVal}
    listToDo += [dictItem]
objTxtFile.close()

#Display existing 'ToDo' list to the user
print("\nWelcome.  The following 'ToDo' list awaits you; get busy!")
print("\n" + strDictHeader)
for dictItem in listToDo:
    for strDictKey in dictItem:
        print(strDictKey + ", " + dictItem[strDictKey])

#Display Menu of options for user to choose from
#Continues to loop through the options until the user chooses to exit
while True:
    print("\nPlease make a selection from the Menu below (enter: 1-5)")
    print(strOptions)
    intFlag = 0
    strUserOption = input("Enter your selection: ")

    #Option 1: Display 'ToDo' list
    if strUserOption == "1":
        print("\n" + strDictHeader)
        for dictItem in listToDo:
            for strDictKey in dictItem:
                print(strDictKey + ", " + dictItem[strDictKey])

    #Option 2: Enter a new item in 'ToDo'. First, check to see if it's a blank entry or if the item already exists
    elif strUserOption == "2":
        strItemInput = input("Enter item to be added to 'ToDo' list: ")
        if strItemInput == "":
            print("Invalid entry was not saved.")
            continue
        else:
            for dictItem in listToDo:
                for strDictKey in dictItem:
                    if strDictKey == strItemInput.title():
                        intFlag += 1
                    else: intFlag += 0
            if intFlag > 0:
                print("\n'" + strItemInput.title() + "' is already on the list and cannot be added again.")
            else:
                while True:
                    strPriorityInput = input("Enter the priority level of '" + strItemInput.title() + "': ")
                    if strPriorityInput != "":
                        dictItem = {strItemInput.title(): strPriorityInput.lower()}
                        listToDo += [dictItem]
                        break
                    else: print("Priority level cannot be blank.  Please enter a valid priority level.")

    #Option 3: Delete an item from 'ToDo'.  First, check to see if it already exists
    elif strUserOption == "3":
        strItemInput = input("Enter the item you'd like to remove from the list: ")
        for dictItem in listToDo:
            for strDictKey in dictItem:
                if strDictKey == strItemInput.title():
                    listToDo.remove(dictItem)
                    intFlag += 1
                else: intFlag += 0
        if intFlag > 0:
            print("\n'" + strItemInput.title() + "' was successfully removed.")
        else: print("\n'" + strItemInput.title() + "' was not a valid entry in the list.  Please try again.")

    #Option 4: Save list to 'Todo.txt'
    elif strUserOption == "4":
        objTxtFile = open(objFileLoc, "w")
        for dictItem in listToDo:
            for strDictKey in dictItem:
                objTxtFile.write(strDictKey.title() + "," + dictItem[strDictKey] + "\n")
        objTxtFile.close()
        print("\nFile was saved.")

    #Option 5: Quit the program.  Save before quitting (i.e. 'break')
    elif strUserOption == "5":
        objTxtFile = open(objFileLoc, "w")
        for dictItem in listToDo:
            for strDictKey in dictItem:
                objTxtFile.write(strDictKey.title() + "," + dictItem[strDictKey] + "\n")
        objTxtFile.close()
        break

    #Option 6: Catch erroneous inputs and restart the loop
    else: print("Invalid selection.  Please enter a valid selection: ")

#Display location of text file and wait for the user to respond before closing
print("\nList was saved here: " + objFileLoc)
input("\nPress enter to exit: ")