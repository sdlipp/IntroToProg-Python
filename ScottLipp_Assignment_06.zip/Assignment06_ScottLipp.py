'''
Title:  Assignment 06 - Working with Functions and Classes
Developer:  Scott Lipp
Created on:  5/5/2018
Class:  IT FDN 100 A: Intro to Programming (Python)
Change Log:  N/A
Purpose:    This program allows a user to import and edit a To-Do list from a text file.
            It introduces the concept of working with functions and classes for
            organizing code into readable, re-usable, modular components.
'''

#--------------------  Data  --------------------#
objFileLoc = "C:\_PythonClass\Todo.txt"
strMenu = "\n\
\t1: Display 'ToDo' list\n\
\t2: Add an item to 'ToDo' list\n\
\t3: Remove an item from 'ToDo' list\n\
\t4: Save the current list\n\
\t5: Exit the program\n"
strHeader = "ITEM, PRIORITY\n---------------"

#--------------------  Processing --------------------#
class MainProgram(object):
    """For retrieving, displaying, and altering a To-Do list from a text file"""

    @staticmethod
    def dataLoad(fileName):
        """Loads the data from a text file into program"""

        listRetrieve = []
        objTxtFile = open(fileName, "r")
        for row in objTxtFile:
            strTask, strPriority = row.strip().split(",")
            dictItem = {"Task": strTask, "Priority": strPriority}
            listRetrieve.append(dictItem)
        objTxtFile.close()
        return listRetrieve

    @staticmethod
    def displayData(listName):
        """Displays the contents of the To-Do list"""

        print("\n" + strHeader)
        for row in listName:
            print(row["Task"] + ", " + row["Priority"])

    @staticmethod
    def dataSave(listName, fileName):
        """Saves the To-Do list to the text file"""

        objTxtFile = open(fileName, "w")
        for row in listName:
            objTxtFile.write(row["Task"] + "," + row["Priority"] + "\n")
        objTxtFile.close()

    @staticmethod
    def rowAdd(listName, dictName):
        """Adds a new task and its priority to the To-Do list"""

        boolAdd = False
        for row in listName:
            if row["Task"] == dictName["Task"]:
                boolAdd = True
        if boolAdd == False:
            listName.append(dictName)
        return [listName, boolAdd]

    @staticmethod
    def rowDelete(listName, strItem):
        """Delets an existing task and its priority from the To-Do list"""

        boolDelete = False
        for row in listName:
            if row["Task"] == strItem:
                listName.remove(row)
                boolDelete = True
        return [listName, boolDelete]

    @staticmethod
    def menuLoop(listName):
        """Loops through the menu of options to allow the user to view, modify, and save the To-Do list"""

        while True:
            print(strMenu)
            strSelect = input("Enter your selection (1-5): ")
            if strSelect == "1":
                MainProgram.displayData(listName)
            elif strSelect == "2":
                while True:
                    strTask = input("Enter the name of the task you'd like to add: ")
                    if strTask == "":
                        print("Task name cannot be empty.")
                    else: break
                while True:
                    strPriority = input("Enter the priority level for '" + strTask.title() + "': ")
                    if strPriority == "":
                        print("Priority level cannot be empty.")
                    else: break
                dictItem = {"Task": strTask.title(), "Priority": strPriority.lower()}
                listIO = MainProgram.rowAdd(listName, dictItem)
                listName, boolFlag = listIO
                if boolFlag == True:
                    print("\n'" + strTask.title() + "' cannot be added because it's already on the list.")
                else: print("\n'" + strTask.title() + "' was successfully added.")
            elif strSelect == "3":
                strTask = input("Enter the task you'd like to remove: ")
                listIO = MainProgram.rowDelete(listName, strTask.title())
                listName, boolFlag = listIO
                if boolFlag == True:
                    print("\n'" + strTask.title() + "' was successfully deleted from the list.")
                else: print("\n'" + strTask.title() + "' was not found in the list.")
            elif strSelect == "4":
                MainProgram.dataSave(listName, objFileLoc)
                print("\nFile was saved.")
            elif strSelect == "5":
                MainProgram.dataSave(listName, objFileLoc)
                break
            else: print("\nInvalid selection. Please try again.")

        print("\nList was saved here: " + objFileLoc)
        input("\nPress enter to exit: ")

#-------------------- Program Start --------------------#

listToDo = MainProgram.dataLoad(objFileLoc)
MainProgram.displayData(listToDo)
MainProgram.menuLoop(listToDo)